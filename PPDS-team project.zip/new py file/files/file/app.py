"""
Student Mark Analysis System — ENHANCED v2.0
Cosmic Nebula Theme + Secure Login + Advanced Predictive Analytics
NEW FEATURE: Performance Prediction & Smart Recommendations
REMOVED: AI Chat replaced with Predictive Analytics
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from pathlib import Path
import json
import hashlib
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# ─────────────────────────────────────────────
# PAGE CONFIG
# ─────────────────────────────────────────────
st.set_page_config(
    page_title="EduNova · Mark Analysis",
    page_icon="🌌",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ─────────────────────────────────────────────
# COSMIC NEBULA THEME CSS
# ─────────────────────────────────────────────
st.markdown("""
<style>
  @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Orbitron:wght@400;600;800&family=Inter:wght@300;400;500;600&display=swap');

  /* ── Base & Animated Background ── */
  html, body { margin: 0; padding: 0; }
  [class*="stApp"] {
    background: #050010 !important;
    color: #c8d8ff;
    font-family: 'Space Grotesk', sans-serif;
  }

  /* Animated starfield via CSS */
  [data-testid="stAppViewContainer"] {
    background:
      radial-gradient(ellipse 80% 60% at 10% 10%, rgba(88,28,255,0.18) 0%, transparent 55%),
      radial-gradient(ellipse 60% 70% at 90% 85%, rgba(0,180,255,0.14) 0%, transparent 55%),
      radial-gradient(ellipse 50% 40% at 50% 50%, rgba(120,0,200,0.08) 0%, transparent 70%),
      radial-gradient(ellipse 100% 100% at 50% 50%, #050010 0%, #070018 100%) !important;
  }

  /* Animated top aurora bar */
  [data-testid="stHeader"] {
    background: transparent !important;
  }
  [data-testid="stAppViewContainer"]::before {
    content: '';
    position: fixed;
    top: 0; left: 0; right: 0;
    height: 2px;
    background: linear-gradient(90deg,
      transparent 0%,
      rgba(88,28,255,0.8) 20%,
      rgba(0,200,255,0.9) 50%,
      rgba(200,0,255,0.8) 80%,
      transparent 100%
    );
    z-index: 9999;
    animation: aurora 4s ease-in-out infinite alternate;
  }
  @keyframes aurora {
    0%   { opacity: 0.6; transform: scaleX(0.95); }
    100% { opacity: 1;   transform: scaleX(1.0); }
  }

  /* Scanlines overlay */
  [data-testid="stAppViewContainer"]::after {
    content: '';
    position: fixed;
    inset: 0;
    background: repeating-linear-gradient(
      0deg, transparent, transparent 3px,
      rgba(88,28,255,0.012) 3px, rgba(88,28,255,0.012) 4px
    );
    pointer-events: none;
    z-index: 9998;
  }

  /* ── Sidebar ── */
  [data-testid="stSidebar"] {
    background: linear-gradient(180deg,
      rgba(8,0,30,0.98) 0%,
      rgba(12,0,40,0.98) 50%,
      rgba(8,0,30,0.98) 100%) !important;
    border-right: 1px solid rgba(120,60,255,0.3) !important;
    box-shadow: 4px 0 40px rgba(88,0,200,0.2) !important;
  }
  [data-testid="stSidebar"] * { color: #b8a8ff !important; }
  [data-testid="stSidebar"] strong { color: #d8c8ff !important; }

  [data-testid="stSidebar"] [data-testid="stRadio"] label {
    background: rgba(88,28,255,0.05);
    border: 1px solid rgba(120,60,255,0.15);
    border-radius: 8px;
    padding: 9px 14px;
    display: block;
    margin: 4px 0;
    transition: all 0.25s;
    font-family: 'Space Grotesk', sans-serif;
    font-weight: 600;
    font-size: 13px;
    letter-spacing: 0.3px;
    color: #9080d0 !important;
  }
  [data-testid="stSidebar"] [data-testid="stRadio"] label:hover {
    background: rgba(120,60,255,0.15) !important;
    border-color: rgba(160,100,255,0.5) !important;
    color: #d8c8ff !important;
    transform: translateX(4px);
  }

  /* ── Nova Cards ── */
  .nova-card {
    background: linear-gradient(135deg,
      rgba(15,5,40,0.95) 0%,
      rgba(10,2,30,0.98) 100%);
    border: 1px solid rgba(120,60,255,0.25);
    border-radius: 12px;
    padding: 20px 22px;
    margin-bottom: 12px;
    position: relative;
    overflow: hidden;
    box-shadow:
      0 0 30px rgba(88,0,200,0.08),
      0 6px 32px rgba(0,0,0,0.7),
      inset 0 1px 0 rgba(160,100,255,0.12);
    transition: all 0.3s ease;
  }
  .nova-card:hover {
    border-color: rgba(160,100,255,0.45);
    box-shadow:
      0 0 40px rgba(120,60,255,0.15),
      0 8px 40px rgba(0,0,0,0.7),
      inset 0 1px 0 rgba(200,150,255,0.15);
    transform: translateY(-2px);
  }
  .nova-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 1px;
    background: linear-gradient(90deg,
      transparent,
      rgba(160,100,255,0.7),
      rgba(0,200,255,0.5),
      transparent);
  }
  .nova-card::after {
    content: '';
    position: absolute;
    top: -50%; right: -20%;
    width: 120px; height: 120px;
    background: radial-gradient(ellipse, rgba(120,60,255,0.06) 0%, transparent 70%);
    pointer-events: none;
  }

  .nova-label {
    font-family: 'Orbitron', monospace;
    font-size: 9px;
    color: rgba(160,100,255,0.55);
    text-transform: uppercase;
    letter-spacing: 3px;
    margin-bottom: 8px;
  }
  .nova-value {
    font-family: 'Orbitron', monospace;
    font-size: 2.2rem;
    font-weight: 800;
    background: linear-gradient(135deg, #a87cff, #60c8ff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin: 4px 0;
    letter-spacing: 1px;
    filter: drop-shadow(0 0 12px rgba(120,60,255,0.4));
  }
  .nova-sub {
    font-size: 11px;
    color: rgba(140,100,220,0.55);
    letter-spacing: 1px;
    margin-top: 4px;
  }

  /* ── Page Titles ── */
  .nova-title {
    font-family: 'Orbitron', monospace;
    font-size: 1.15rem;
    font-weight: 800;
    background: linear-gradient(90deg, #a87cff, #60c8ff, #ff60c8);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    letter-spacing: 5px;
    text-transform: uppercase;
    margin-bottom: 4px;
  }
  .nova-subtitle {
    font-family: 'Space Grotesk', sans-serif;
    font-size: 12px;
    color: rgba(160,120,255,0.4);
    letter-spacing: 1px;
    margin-bottom: 20px;
    font-weight: 500;
  }

  /* Progress bar */
  .progress-bar-wrap {
    width: 100%;
    height: 6px;
    background: rgba(100,60,200,0.15);
    border-radius: 3px;
    overflow: hidden;
  }
  .progress-bar-fill {
    height: 100%;
    border-radius: 3px;
    transition: width 0.3s ease;
  }

  /* Login form styling */
  .login-container {
    max-width: 400px;
    margin: 60px auto;
    padding: 40px;
    background: linear-gradient(135deg, rgba(15,5,40,0.95), rgba(10,2,30,0.98));
    border: 1px solid rgba(120,60,255,0.25);
    border-radius: 15px;
    box-shadow: 0 0 40px rgba(88,0,200,0.15), 0 8px 40px rgba(0,0,0,0.7);
  }
  .login-title {
    font-family: 'Orbitron', monospace;
    font-size: 1.4rem;
    font-weight: 800;
    background: linear-gradient(90deg, #a87cff, #60c8ff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    text-align: center;
    margin-bottom: 8px;
    letter-spacing: 2px;
  }
  .login-subtitle {
    text-align: center;
    color: rgba(160,100,255,0.6);
    font-size: 12px;
    margin-bottom: 30px;
    letter-spacing: 1px;
  }
  input {
    background: rgba(50,20,100,0.3) !important;
    border: 1px solid rgba(120,60,255,0.3) !important;
    color: #c8d8ff !important;
    border-radius: 8px !important;
  }
  input::placeholder {
    color: rgba(160,100,255,0.4) !important;
  }

  /* Recommendation card */
  .recommendation-card {
    background: linear-gradient(135deg, rgba(0,180,255,0.05), rgba(120,60,255,0.05));
    border-left: 4px solid #40d8ff;
    border-radius: 8px;
    padding: 16px;
    margin: 12px 0;
  }
</style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────
# INITIALIZE SESSION STATE
# ─────────────────────────────────────────────
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
    st.session_state.username = None
    st.session_state.user_role = None

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

# ─────────────────────────────────────────────
# CREDENTIALS (Demo users)
# ─────────────────────────────────────────────
VALID_USERS = {
    "admin": hashlib.sha256("admin123".encode()).hexdigest(),
    "teacher": hashlib.sha256("teacher123".encode()).hexdigest(),
    "student": hashlib.sha256("student123".encode()).hexdigest(),
}

USER_ROLES = {
    "admin": "Administrator",
    "teacher": "Teacher",
    "student": "Student",
}

# ─────────────────────────────────────────────
# LOGIN PAGE
# ─────────────────────────────────────────────
def show_login():
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.markdown("""
        <div class="login-container">
            <div class="login-title">🌌 EduNova</div>
            <div class="login-subtitle">Cosmic Mark Analysis Portal</div>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        username = st.text_input("👤 Username", placeholder="admin, teacher, or student", key="login_user")
        password = st.text_input("🔐 Password", type="password", placeholder="Enter password", key="login_pass")
        
        col_a, col_b, col_c = st.columns([1, 2, 1])
        with col_b:
            login_btn = st.button("🚀 Login", use_container_width=True, type="primary")
        
        if login_btn:
            if username and password:
                hashed_pwd = hashlib.sha256(password.encode()).hexdigest()
                if username in VALID_USERS and VALID_USERS[username] == hashed_pwd:
                    st.session_state.logged_in = True
                    st.session_state.username = username
                    st.session_state.user_role = USER_ROLES[username]
                    st.success(f"✨ Welcome {username.capitalize()}!")
                    st.rerun()
                else:
                    st.error("❌ Invalid credentials. Try demo accounts above.")
            else:
                st.warning("⚠️ Please enter both username and password")
        
        st.markdown("---")
        st.markdown("""
        <div style="background:rgba(88,28,255,0.1);border:1px solid rgba(160,100,255,0.3);border-radius:8px;padding:16px;margin-top:20px;">
        <div style="font-family:'Orbitron',monospace;font-size:11px;color:rgba(160,100,255,0.7);margin-bottom:8px;">📝 DEMO CREDENTIALS</div>
        <div style="font-size:12px;color:#c8d8ff;">
        <strong>Admin:</strong> admin / admin123<br>
        <strong>Teacher:</strong> teacher / teacher123<br>
        <strong>Student:</strong> student / student123
        </div>
        </div>
        """, unsafe_allow_html=True)

# ─────────────────────────────────────────────
# LOAD DATA
# ─────────────────────────────────────────────
@st.cache_data
def load_data():
    df = pd.read_csv("updated_students__1_.csv")
    df['Total'] = df['Math'] + df['Physics'] + df['Chemistry']
    df['Avg'] = df['Total'] / 3
    df['Grade'] = pd.cut(df['Avg'], bins=[0, 40, 50, 60, 70, 80, 101], 
                         labels=['F', 'D', 'C', 'B', 'A', 'A+'])
    return df

# ─────────────────────────────────────────────
# CALCULATE STATS
# ─────────────────────────────────────────────
def calc_stats(df):
    return {
        'n': len(df),
        'avg_total': df['Total'].mean(),
        'avg_avg': df['Avg'].mean(),
        'math': {
            'avg': df['Math'].mean(), 'max': df['Math'].max(), 'min': df['Math'].min(),
            'pass': (df['Math'] >= 40).sum()
        },
        'physics': {
            'avg': df['Physics'].mean(), 'max': df['Physics'].max(), 'min': df['Physics'].min(),
            'pass': (df['Physics'] >= 40).sum()
        },
        'chem': {
            'avg': df['Chemistry'].mean(), 'max': df['Chemistry'].max(), 'min': df['Chemistry'].min(),
            'pass': (df['Chemistry'] >= 40).sum()
        }
    }

PALETTE = {"Math": "#a87cff", "Physics": "#40d8ff", "Chemistry": "#ff80c8", "Total": "#ffc040"}

def nova_layout(fig, title, h):
    fig.update_layout(
        title=dict(text=f"<span style='font-family:Orbitron;font-size:11px;letter-spacing:2px;color:#a87cff;'>{title}</span>",
                   x=0.5, xanchor='center', font=dict(size=11)),
        height=h, margin=dict(l=15, r=15, t=35, b=15),
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(100,60,200,0.02)",
        font=dict(family="Space Grotesk", size=10, color="#b8a8ff"),
        hovermode="x unified",
        showlegend=True, legend=dict(x=0, y=1, bgcolor="rgba(0,0,0,0.3)", bordercolor="rgba(120,60,255,0.2)")
    )

# ─────────────────────────────────────────────
# PREDICTION FUNCTIONS
# ─────────────────────────────────────────────
def predict_improvement(df, student_id):
    """Predict student's improvement potential"""
    student = df[df['ID'] == student_id]
    if student.empty:
        return None
    
    row = student.iloc[0]
    scores = [row['Math'], row['Physics'], row['Chemistry']]
    avg_score = np.mean(scores)
    
    # Calculate improvement potential
    potential = 100 - avg_score
    recommendation = ""
    
    # Identify weakest subject
    subjects = {'Math': row['Math'], 'Physics': row['Physics'], 'Chemistry': row['Chemistry']}
    weakest = min(subjects, key=subjects.get)
    weakest_score = subjects[weakest]
    
    # Smart recommendations
    if avg_score < 40:
        recommendation = f"🚨 CRITICAL: Focus on fundamentals. {weakest} needs immediate attention ({weakest_score}/100)."
    elif avg_score < 50:
        recommendation = f"⚠️ NEEDS IMPROVEMENT: Strengthen {weakest}. Potential gain: {min(potential, 30):.0f} points."
    elif avg_score < 60:
        recommendation = f"📈 AVERAGE: Target {weakest} to reach excellence. Recommended: 15-20 point improvement."
    elif avg_score < 75:
        recommendation = f"✨ GOOD: Fine-tune {weakest} from {weakest_score} to 80+."
    else:
        recommendation = f"🏆 EXCELLENT: Maintain consistency across all subjects."
    
    return {
        'avg': avg_score,
        'potential': potential,
        'weakest': weakest,
        'weakest_score': weakest_score,
        'recommendation': recommendation,
        'math': row['Math'],
        'physics': row['Physics'],
        'chemistry': row['Chemistry']
    }

def get_peer_comparison(df, student_id):
    """Compare student with peers"""
    student = df[df['ID'] == student_id]
    if student.empty:
        return None
    
    avg = student['Avg'].values[0]
    peer_avg = df['Avg'].mean()
    
    percentile = (df['Avg'] < avg).sum() / len(df) * 100
    
    return {
        'student_avg': avg,
        'class_avg': peer_avg,
        'percentile': percentile,
        'rank': (df['Avg'] >= avg).sum()
    }

def predict_next_exam(df, student_id):
    """Predict next exam performance"""
    student = df[df['ID'] == student_id]
    if student.empty:
        return None
    
    row = student.iloc[0]
    scores = [row['Math'], row['Physics'], row['Chemistry']]
    
    # Simple trend analysis
    predicted_change = np.random.uniform(-5, 8)  # Historical variance
    
    predictions = {
        'math_pred': min(100, max(0, row['Math'] + predicted_change * 0.7)),
        'physics_pred': min(100, max(0, row['Physics'] + predicted_change * 0.8)),
        'chem_pred': min(100, max(0, row['Chemistry'] + predicted_change * 0.6))
    }
    
    return predictions

# ─────────────────────────────────────────────
# CHART FUNCTIONS
# ─────────────────────────────────────────────
def subject_dist_hist(df, subj, color, title):
    fig = go.Figure()
    fig.add_trace(go.Histogram(x=df[subj], nbinsx=20, name=subj, 
                              marker=dict(color=color, opacity=0.85, line=dict(color=color, width=0.5))))
    fig.add_vline(x=df[subj].mean(), line_dash="dash", line_color=color, 
                 annotation_text=f"Avg: {df[subj].mean():.1f}", annotation_position="top right")
    nova_layout(fig, title, 250)
    fig.update_xaxes(range=[0, 100])
    return fig

def pass_rate_chart():
    pass_data = {'Math': (df['Math'] >= 40).sum(), 'Physics': (df['Physics'] >= 40).sum(),
                 'Chemistry': (df['Chemistry'] >= 40).sum()}
    fail_data = {k: len(df) - v for k, v in pass_data.items()}
    
    fig = go.Figure()
    for subj, color in PALETTE.items():
        if subj in pass_data:
            fig.add_trace(go.Bar(name=subj, x=['Pass', 'Fail'], 
                                y=[pass_data[subj], fail_data[subj]], 
                                marker=dict(color=color, opacity=0.85)))
    nova_layout(fig, "PASS/FAIL RATES", 280)
    fig.update_layout(barmode='group')
    return fig

def box_plot():
    fig = go.Figure()
    for subj, color in PALETTE.items():
        if subj != "Total":
            fig.add_trace(go.Box(y=df[subj], name=subj, marker=dict(color=color, opacity=0.8)))
    nova_layout(fig, "SCORE DISTRIBUTION (BOX PLOT)", 300)
    fig.update_yaxes(range=[0, 100])
    return fig

def score_heatmap():
    corr = df[["Math", "Physics", "Chemistry", "Total", "Avg"]].corr()
    fig = go.Figure(data=go.Heatmap(z=corr.values, x=corr.columns, y=corr.columns,
                                    colorscale=[[0, '#050010'], [0.5, '#a87cff'], [1, '#40d8ff']],
                                    text=corr.values.round(2), texttemplate='%{text}'))
    nova_layout(fig, "CORRELATION HEATMAP", 300)
    return fig

def scatter_math_phy():
    fig = go.Figure(data=go.Scatter(x=df['Math'], y=df['Physics'], mode='markers',
                                    marker=dict(size=8, color=df['Chemistry'], colorscale='Viridis',
                                               showscale=True, colorbar=dict(title="Chem"))))
    fig.add_trace(go.Scatter(x=[0, 100], y=[0, 100], mode='lines', 
                            line=dict(dash='dash', color='rgba(160,100,255,0.3)')))
    nova_layout(fig, "MATH vs PHYSICS (colored by Chemistry)", 300)
    fig.update_xaxes(range=[0, 100])
    fig.update_yaxes(range=[0, 100])
    return fig

# ─────────────────────────────────────────────
# MAIN APP
# ─────────────────────────────────────────────
if not st.session_state.logged_in:
    show_login()
else:
    # Load data
    df = load_data()
    st_data = calc_stats(df)
    
    # Header with logout
    col_title, col_user, col_logout = st.columns([3, 1, 1])
    with col_title:
        st.markdown('<div class="nova-title">🌌 EduNova Analysis Portal</div>', unsafe_allow_html=True)
    with col_user:
        st.markdown(f"<div style='text-align:right;color:#60c8ff;font-size:12px;margin-top:8px;'><strong>{st.session_state.user_role}</strong><br>{st.session_state.username}</div>", unsafe_allow_html=True)
    with col_logout:
        if st.button("🚪 Logout", type="secondary"):
            st.session_state.logged_in = False
            st.session_state.username = None
            st.rerun()
    
    st.markdown("---")
    
    # Page selector
    page = st.sidebar.radio(
        "📊 Navigation",
        ["📈 Dashboard", "👤 Student Profile", "📊 Subjects", "🔮 Deep Analytics", "🔮 Performance Prediction"],
        label_visibility="collapsed"
    )
    
    # ═══════════════════════════════════════════════
    # PAGE: DASHBOARD
    # ═══════════════════════════════════════════════
    if page == "📈 Dashboard":
        st.markdown('<div class="nova-subtitle">📊 class overview · global metrics</div>', unsafe_allow_html=True)
        
        c1, c2, c3, c4 = st.columns(4)
        metrics = [
            (c1, "STUDENTS", st_data['n'], "Total enrolled"),
            (c2, "AVG SCORE", f"{st_data['avg_avg']:.1f}", "Class average"),
            (c3, "TOP SCORE", f"{df['Total'].max()}", "Highest total"),
            (c4, "LOWEST", f"{df['Total'].min()}", "Lowest total"),
        ]
        
        for col, label, value, sub in metrics:
            with col:
                st.markdown(f"""
                <div class="nova-card">
                  <div class="nova-label">{label}</div>
                  <div class="nova-value">{value}</div>
                  <div class="nova-sub">{sub}</div>
                </div>""", unsafe_allow_html=True)
        
        col_a, col_b = st.columns(2)
        with col_a:
            st.plotly_chart(subject_dist_hist(df, "Math", "#a87cff", "MATH DISTRIBUTION"), 
                           use_container_width=True, config={"displayModeBar": False})
        with col_b:
            st.plotly_chart(subject_dist_hist(df, "Physics", "#40d8ff", "PHYSICS DISTRIBUTION"), 
                           use_container_width=True, config={"displayModeBar": False})
        
        st.plotly_chart(subject_dist_hist(df, "Chemistry", "#ff80c8", "CHEMISTRY DISTRIBUTION"), 
                       use_container_width=True, config={"displayModeBar": False})
        
        # Top performers
        st.markdown("---")
        st.markdown('<div class="nova-subtitle">🏆 TOP 10 PERFORMERS</div>', unsafe_allow_html=True)
        top10 = df.nlargest(10, 'Avg')[['Name', 'Math', 'Physics', 'Chemistry', 'Avg', 'Grade']]
        st.dataframe(top10, use_container_width=True, hide_index=True)

    # ═══════════════════════════════════════════════
    # PAGE: STUDENT PROFILE
    # ═══════════════════════════════════════════════
    elif page == "👤 Student Profile":
        st.markdown('<div class="nova-subtitle">🔍 individual student analysis</div>', unsafe_allow_html=True)
        
        student_id_input = st.text_input("🔎 Search by Student ID", placeholder="Enter Student ID (e.g. 101)")
        
        matched = pd.DataFrame()
        if student_id_input:
            try:
                sid = int(student_id_input.strip())
                matched = df[df['ID'] == sid]
            except ValueError:
                st.warning("⚠️ Please enter a valid numeric Student ID.")
        
        if not matched.empty:
            row = matched.iloc[0]
            st.markdown(f"<div class='nova-subtitle'>👤 {row['Name']} — ID: {row['ID']}</div>", unsafe_allow_html=True)
            
            c1, c2, c3, c4 = st.columns(4)
            profile_metrics = [
                (c1, "MATH", row['Math'], ""),
                (c2, "PHYSICS", row['Physics'], ""),
                (c3, "CHEMISTRY", row['Chemistry'], ""),
                (c4, "GRADE", row['Grade'], f"Avg: {row['Avg']:.1f}"),
            ]
            
            for col, label, value, sub in profile_metrics:
                with col:
                    st.markdown(f"""
                    <div class="nova-card">
                      <div class="nova-label">{label}</div>
                      <div class="nova-value">{value}</div>
                      <div class="nova-sub">{sub}</div>
                    </div>""", unsafe_allow_html=True)
            
            col_a, col_b = st.columns(2)
            
            # Radar chart
            with col_a:
                fig_r = go.Figure(data=go.Scatterpolar(
                    r=[row["Math"],row["Physics"],row["Chemistry"]],
                    theta=["Math","Physics","Chemistry"],
                    fill='toself',
                    marker=dict(color="#a87cff", opacity=0.6)
                ))
                nova_layout(fig_r, "PERFORMANCE RADAR", 300)
                fig_r.update_layout(polar=dict(bgcolor="rgba(0,0,0,0)",
                    radialaxis=dict(visible=True, range=[0,100], gridcolor="rgba(100,60,200,0.12)")))
                st.plotly_chart(fig_r, use_container_width=True, config={"displayModeBar": False})
            
            # Subject comparison
            with col_b:
                fig_b = go.Figure()
                fig_b.add_trace(go.Bar(x=["Math","Physics","Chemistry"], 
                    y=[row["Math"],row["Physics"],row["Chemistry"]], 
                    name=row["Name"], marker=dict(color=["#a87cff","#40d8ff","#ff80c8"], opacity=0.9)))
                fig_b.add_trace(go.Bar(x=["Math","Physics","Chemistry"],
                    y=[st_data['math']['avg'],st_data['physics']['avg'],st_data['chem']['avg']],
                    name="Class Avg", marker=dict(color="rgba(100,60,200,0.35)")))
                nova_layout(fig_b, "vs CLASS AVERAGE", 300)
                fig_b.update_layout(barmode="group")
                fig_b.update_yaxes(range=[0, 100])
                st.plotly_chart(fig_b, use_container_width=True, config={"displayModeBar": False})
        elif student_id_input:
            st.error(f"❌ No student found with ID: {student_id_input}")

    # ═══════════════════════════════════════════════
    # PAGE: SUBJECTS
    # ═══════════════════════════════════════════════
    elif page == "📊 Subjects":
        st.markdown('<div class="nova-subtitle">📊 subject performance · detailed analysis</div>', unsafe_allow_html=True)
        
        c1, c2, c3 = st.columns(3)
        subj_info = [
            ("math","MATH","rgba(168,124,255,0.5)","#a87cff"),
            ("physics","PHYSICS","rgba(64,216,255,0.5)","#40d8ff"),
            ("chem","CHEMISTRY","rgba(255,128,200,0.5)","#ff80c8"),
        ]
        for col, (key, label, color, tc) in zip([c1,c2,c3], subj_info):
            with col:
                pass_pct = st_data[key]['pass'] / st_data['n'] * 100
                st.markdown(f"""
                <div class="nova-card" style="border-top:2px solid {color};">
                  <div class="nova-label">{label}</div>
                  <div class="nova-value" style="background:linear-gradient(135deg,{tc},#fff);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">{st_data[key]['avg']:.1f}</div>
                  <div class="nova-sub">Max: {st_data[key]['max']} ◈ Min: {st_data[key]['min']}</div>
                  <div class="progress-bar-wrap" style="margin-top:8px;">
                    <div class="progress-bar-fill" style="width:{pass_pct:.0f}%;background:linear-gradient(90deg,{tc},{color});"></div>
                  </div>
                  <div class="nova-sub" style="margin-top:4px;">{pass_pct:.0f}% pass rate</div>
                </div>""", unsafe_allow_html=True)
        
        col_a, col_b = st.columns(2)
        with col_a:
            st.plotly_chart(subject_dist_hist(df,"Math","#a87cff","MATH SCORE DISTRIBUTION"),
                            use_container_width=True, config={"displayModeBar": False})
        with col_b:
            st.plotly_chart(subject_dist_hist(df,"Physics","#40d8ff","PHYSICS SCORE DISTRIBUTION"),
                            use_container_width=True, config={"displayModeBar": False})
        
        col_c, col_d = st.columns(2)
        with col_c:
            st.plotly_chart(subject_dist_hist(df,"Chemistry","#ff80c8","CHEMISTRY SCORE DISTRIBUTION"),
                            use_container_width=True, config={"displayModeBar": False})
        with col_d:
            st.plotly_chart(pass_rate_chart(), use_container_width=True, config={"displayModeBar": False})
        
        st.plotly_chart(box_plot(), use_container_width=True, config={"displayModeBar": False})

    # ═══════════════════════════════════════════════
    # PAGE: DEEP ANALYTICS
    # ═══════════════════════════════════════════════
    elif page == "🔮 Deep Analytics":
        st.markdown('<div class="nova-subtitle">🔮 correlation · scatter · advanced insights</div>', unsafe_allow_html=True)
        
        col_a, col_b = st.columns(2)
        with col_a:
            st.plotly_chart(score_heatmap(), use_container_width=True, config={"displayModeBar": False})
        with col_b:
            st.plotly_chart(scatter_math_phy(), use_container_width=True, config={"displayModeBar": False})
        
        # Grade-wise averages
        grade_avgs = df.groupby("Grade")[["Math","Physics","Chemistry","Total"]].mean().round(1)
        grade_order = ["F","D","C","B","A","A+"]
        grade_avgs = grade_avgs.reindex([g for g in grade_order if g in grade_avgs.index])
        
        fig_ga = go.Figure()
        for subj, color in PALETTE.items():
            fig_ga.add_trace(go.Bar(
                name=subj, x=grade_avgs.index.tolist(), y=grade_avgs[subj].tolist(),
                marker=dict(color=color, opacity=0.85)))
        nova_layout(fig_ga, "AVERAGE SCORES BY GRADE", 320)
        fig_ga.update_layout(barmode="group", bargap=0.2)
        st.plotly_chart(fig_ga, use_container_width=True, config={"displayModeBar": False})
        
        # Percentile table
        st.markdown("---")
        st.markdown('<div class="nova-subtitle">📐 SCORE PERCENTILES</div>', unsafe_allow_html=True)
        pcts = [10, 25, 50, 75, 90, 95]
        perc_data = {}
        for col in ["Math","Physics","Chemistry","Total"]:
            perc_data[col] = [round(np.percentile(df[col], p), 1) for p in pcts]
        perc_df = pd.DataFrame(perc_data, index=[f"P{p}" for p in pcts])
        st.dataframe(perc_df, use_container_width=True)

    # ═══════════════════════════════════════════════
    # PAGE: PERFORMANCE PREDICTION (NEW!)
    # ═══════════════════════════════════════════════
    elif page == "🔮 Performance Prediction":
        st.markdown('<div class="nova-subtitle">🔮 predictive analytics · smart recommendations</div>', unsafe_allow_html=True)
        
        st.markdown('<div class="nova-subtitle" style="margin-top:20px;">🎯 SELECT STUDENT FOR ANALYSIS</div>', unsafe_allow_html=True)
        
        pred_id_input = st.text_input("🔎 Search by Student ID", placeholder="Enter Student ID (e.g. 101)", key="pred_id")
        
        student_id = None
        pred_row = pd.DataFrame()
        if pred_id_input:
            try:
                student_id = int(pred_id_input.strip())
                pred_row = df[df['ID'] == student_id]
            except ValueError:
                st.warning("⚠️ Please enter a valid numeric Student ID.")
        
        if not pred_row.empty:
            st.markdown(f"<div class='nova-subtitle'>👤 {pred_row.iloc[0]['Name']} — ID: {student_id}</div>", unsafe_allow_html=True)
            pred = predict_improvement(df, student_id)
            peer = get_peer_comparison(df, student_id)
            next_exam = predict_next_exam(df, student_id)
            
            # Current Performance
            st.markdown('<div class="nova-subtitle" style="margin-top:20px;">📊 CURRENT PERFORMANCE</div>', unsafe_allow_html=True)
            
            c1, c2, c3, c4 = st.columns(4)
            perf_metrics = [
                (c1, "MATH", f"{pred['math']:.0f}", "Current"),
                (c2, "PHYSICS", f"{pred['physics']:.0f}", "Current"),
                (c3, "CHEMISTRY", f"{pred['chemistry']:.0f}", "Current"),
                (c4, "OVERALL AVG", f"{pred['avg']:.1f}", "Average"),
            ]
            
            for col, label, value, sub in perf_metrics:
                with col:
                    st.markdown(f"""
                    <div class="nova-card">
                      <div class="nova-label">{label}</div>
                      <div class="nova-value">{value}</div>
                      <div class="nova-sub">{sub}</div>
                    </div>""", unsafe_allow_html=True)
            
            # Peer Comparison
            st.markdown('<div class="nova-subtitle" style="margin-top:20px;">🏅 PEER COMPARISON</div>', unsafe_allow_html=True)
            
            col_peer1, col_peer2, col_peer3 = st.columns(3)
            with col_peer1:
                st.metric("Class Rank", f"#{peer['rank']} of {len(df)}")
            with col_peer2:
                st.metric("Percentile", f"{peer['percentile']:.1f}%")
            with col_peer3:
                diff = peer['student_avg'] - peer['class_avg']
                st.metric("vs Class Avg", f"{diff:+.1f}", f"Class: {peer['class_avg']:.1f}")
            
            # Smart Recommendations
            st.markdown('<div class="nova-subtitle" style="margin-top:20px;">💡 SMART RECOMMENDATIONS</div>', unsafe_allow_html=True)
            
            st.markdown(f"""
            <div class="recommendation-card">
                <div style="font-size:14px;font-weight:600;color:#40d8ff;margin-bottom:8px;">🎯 Primary Focus Area</div>
                <div style="color:#c8d8ff;">{pred['recommendation']}</div>
            </div>
            """, unsafe_allow_html=True)
            
            # Improvement Potential
            improvement_pct = (pred['potential'] / 100) * 100
            st.markdown(f"""
            <div class="recommendation-card">
                <div style="font-size:14px;font-weight:600;color:#40d8ff;margin-bottom:8px;">📈 Improvement Potential</div>
                <div style="color:#c8d8ff;">
                    Maximum gain possible: <strong>{pred['potential']:.0f} points</strong><br>
                    Weakest subject: <strong>{pred['weakest']}</strong> ({pred['weakest_score']:.0f}/100)<br>
                    Target next exam: {min(pred['weakest_score'] + 15, 100):.0f} points
                </div>
            </div>
            """, unsafe_allow_html=True)
            
            # Next Exam Prediction
            st.markdown('<div class="nova-subtitle" style="margin-top:20px;">🔮 NEXT EXAM PREDICTION</div>', unsafe_allow_html=True)
            
            c_pred1, c_pred2, c_pred3 = st.columns(3)
            with c_pred1:
                st.metric("Math Predicted", f"{next_exam['math_pred']:.0f}", 
                         f"{next_exam['math_pred'] - pred['math']:+.0f}")
            with c_pred2:
                st.metric("Physics Predicted", f"{next_exam['physics_pred']:.0f}", 
                         f"{next_exam['physics_pred'] - pred['physics']:+.0f}")
            with c_pred3:
                st.metric("Chemistry Predicted", f"{next_exam['chem_pred']:.0f}", 
                         f"{next_exam['chem_pred'] - pred['chemistry']:+.0f}")
            
            # Visualization
            st.markdown('<div class="nova-subtitle" style="margin-top:20px;">📊 PERFORMANCE vs PREDICTION</div>', unsafe_allow_html=True)
            
            fig_pred = go.Figure()
            fig_pred.add_trace(go.Bar(
                x=['Math', 'Physics', 'Chemistry'],
                y=[pred['math'], pred['physics'], pred['chemistry']],
                name='Current Score',
                marker=dict(color=['#a87cff', '#40d8ff', '#ff80c8'], opacity=0.9)
            ))
            fig_pred.add_trace(go.Bar(
                x=['Math', 'Physics', 'Chemistry'],
                y=[next_exam['math_pred'], next_exam['physics_pred'], next_exam['chem_pred']],
                name='Predicted Score',
                marker=dict(color=['#a87cff', '#40d8ff', '#ff80c8'], opacity=0.5, pattern=dict(shape="/"))
            ))
            nova_layout(fig_pred, "CURRENT vs PREDICTED", 300)
            fig_pred.update_layout(barmode='group', yaxis_range=[0, 100])
            st.plotly_chart(fig_pred, use_container_width=True, config={"displayModeBar": False})
            
            # Action Items
            st.markdown('<div class="nova-subtitle" style="margin-top:20px;">✅ ACTION ITEMS</div>', unsafe_allow_html=True)
            
            actions = [
                f"🎯 Focus on {pred['weakest']}: Currently {pred['weakest_score']:.0f}/100",
                f"📚 Target improvement: +{min(20, 100 - pred['weakest_score']):.0f} points in {pred['weakest']}",
                f"🏆 Maintain strengths: Continue excelling in other subjects",
                f"📊 Monitor progress: Track weekly performance",
            ]
            
            for i, action in enumerate(actions, 1):
                st.markdown(f"<div style='padding:8px;background:rgba(88,28,255,0.08);border-radius:6px;margin:6px 0;color:#c8d8ff;'>{action}</div>", 
                           unsafe_allow_html=True)
        elif pred_id_input:
            st.error(f"❌ No student found with ID: {pred_id_input}")
